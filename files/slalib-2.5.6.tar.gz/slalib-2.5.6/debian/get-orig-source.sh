#!/bin/sh

TMPDIR=$(mktemp --directory)
trap "rm -fr ${TMPDIR} || exit 1" EXIT INT TERM

PACKAGE_NAME=slalib
#
# Download and unpack the main source
# This is the sub directory libraries/sla of the git repository
#
H=138941bc91b29bac6c3ce647ac765025fbd56299
SLA_URL="http://starlink.jach.hawaii.edu/git/?p=starlink.git;a=snapshot;h=${H};sf=tgz"
wget -O ${TMPDIR}/${PACKAGE_NAME}-git.tar.gz "${SLA_URL}"
tar xf ${TMPDIR}/${PACKAGE_NAME}-git.tar.gz -C ${TMPDIR}

#
# Retrieve package version from the AC_INIT(sla, 2.5-6, ussc@star.rl.ac.uk)
# line of configure.ac
#
VERSION=$(echo $(fgrep AC_INIT ${TMPDIR}/starlink/configure.ac |cut -d, -f2 | tr - .))

#
# Touch all files with a specific (release) date to ensure that the 
# MD5 checksum doesn't change.
#
DATE="Fri, 10 Feb 2012 16:37:47 +0000"
touch -d "${DATE}" ${TMPDIR}/starlink ${TMPDIR}/starlink/*

#
# Repack everything into .orig.tar.gz
#
mv ${TMPDIR}/starlink ${TMPDIR}/${PACKAGE_NAME}-${VERSION}
tar cf ${PACKAGE_NAME}_${VERSION}.orig.tar -C ${TMPDIR} ${PACKAGE_NAME}-${VERSION} 
gzip -n -9 -f ${PACKAGE_NAME}_${VERSION}.orig.tar

#
# Check or print out the MD5 checksum
#
case ${VERSION} in
    2.5.6)
	echo "9f1f2c45db34bd8fde5f811cf3366180  ${PACKAGE_NAME}_${VERSION}.orig.tar.gz" | \
	md5sum -c -
	;;
    *)
	md5sum ${PACKAGE_NAME}_${VERSION}.orig.tar.gz
	;;
esac
